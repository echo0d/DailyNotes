/**
 * @author :xmsong
 * @date : 2023/5/28
 */
public class User {
    private String username;
    private int age;
    public void setUsername(String username) {
        this.username = username;
        System.out.println("call setUsername");
    }
    public String getUsername() {
        return username;
    }
    public void setAge(int age) {
        this.age = age;
        System.out.println("call setAge");

    }
    public int getAge() {
        return age;
    }


    @Override
    public String toString() {
        return "{" +
                "username='" + username + '\'' +
                ", age=" + age +
                '}';
    }
}
