/**
 * @author :xmsong
 * @date : 2023/5/28 9:53
 */
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

public class parseObjectTest {
    public static void main( String[] args ){
//序列化
        System.out.println("---序列化---");
        User user1 = new User();
        user1.setAge(66);
        user1.setUsername("test");
        String json1 = JSON.toJSONString(user1);
        System.out.println(json1);
//反序列化
        String json2 = "{\"age\":66,\"username\":\"test\"}";

        System.out.println("---指定.class 反序列化---");
        String user2_1 = JSON.parseObject(json2, User.class).toString(); // 后面的User.class表示反序列化为User类
        System.out.println(user2_1);

        System.out.println("---不指定类 反序列化---");
        JSONObject user2_2 = JSON.parseObject(json2);
        System.out.println(user2_2);

        System.out.println("---指定@type 反序列化---");
        String json3 = "{\"@type\":\"User\", \"age\":66,\"username\":\"test\"}";
        JSONObject user3 = JSON.parseObject(json3);
        System.out.println(user3);
    }

}


//        反序列化
//        这里我们反序列化使用的是parseObject()方法，其实也可以用到parse()方法，parseObject() 本质上也是调用 parse() 进行反序列化的。
//        但是 parseObject() 会额外的将Java对象转为 JSONObject对象，即 JSON.toJSON()；