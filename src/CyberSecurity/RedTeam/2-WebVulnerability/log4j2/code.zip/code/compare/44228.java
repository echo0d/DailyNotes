public String lookup(LogEvent event, String key) {
        if (key == null) {
            return null;
        } else {
            String jndiName = this.convertJndiName(key);

            try {
                JndiManager jndiManager = JndiManager.getDefaultManager();
                Throwable var5 = null;

                String var6;
                try {
                    var6 = Objects.toString(jndiManager.lookup(jndiName), (String)null);
                } catch (Throwable var16) {
                    var5 = var16;
                    throw var16;
                } finally {
                    if (jndiManager != null) {
                        if (var5 != null) {
                            try {
                                jndiManager.close();
                            } catch (Throwable var15) {
                                var5.addSuppressed(var15);
                            }
                        } else {
                            jndiManager.close();
                        }
                    }

                }

                return var6;
            } catch (NamingException var18) {
                LOGGER.warn(LOOKUP, "Error looking up JNDI resource [{}].", jndiName, var18);
                return null;
            }
        }
    }