    public synchronized <T> T lookup(final String name) throws NamingException {
        try {
            URI uri = new URI(name);
            if (uri.getScheme() != null) {
                if (!this.allowedProtocols.contains(uri.getScheme().toLowerCase(Locale.ROOT))) {
                    LOGGER.warn("Log4j JNDI does not allow protocol {}", uri.getScheme());
                    return null;
                }

                if ("ldap".equalsIgnoreCase(uri.getScheme()) || "ldaps".equalsIgnoreCase(uri.getScheme())) {
                    if (!this.allowedHosts.contains(uri.getHost())) {
                        LOGGER.warn("Attempt to access ldap server not in allowed list");
                        return null;
                    }

                    Attributes attributes = this.context.getAttributes(name);
                    if (attributes != null) {
                        Map<String, Attribute> attributeMap = new HashMap();
                        NamingEnumeration<? extends Attribute> enumeration = attributes.getAll();

                        Attribute classNameAttr;
                        while(enumeration.hasMore()) {
                            classNameAttr = (Attribute)enumeration.next();
                            attributeMap.put(classNameAttr.getID(), classNameAttr);
                        }

                        classNameAttr = (Attribute)attributeMap.get("javaClassName");
                        if (attributeMap.get("javaSerializedData") != null) {
                            if (classNameAttr == null) {
                                LOGGER.warn("No class name provided for {}", name);
                                return null;
                            }

                            String className = classNameAttr.get().toString();
                            if (!this.allowedClasses.contains(className)) {
                                LOGGER.warn("Deserialization of {} is not allowed", className);
                                return null;
                            }
                        } else if (attributeMap.get("javaReferenceAddress") != null || attributeMap.get("javaFactory") != null) {
                            LOGGER.warn("Referenceable class is not allowed for {}", name);
                            return null;
                        }
                    }
                }
            }
        } catch (URISyntaxException var8) {
            LOGGER.warn("Invalid JNDI URI - {}", name);
            return null;
        }

        return this.context.lookup(name);
    }
